# Leaflet for Meteor Demo

## How to install
0. curl https://install.meteor.com/ | sh
1. npm install -g meteorite
2. meteor create meteor-leaflet-demo
3. cd meteor-leaflet-demo
4. mrt install leaflet (follow instruction on https://github.com/bevanhunt/meteor-leaflet)
4. meteor
5. open browser to http://localhost:3000
